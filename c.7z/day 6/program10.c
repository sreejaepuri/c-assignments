#include<stdio.h>
void main()
{
int *p1,**p2;
int a=5;
p1=&a;
p2=&p1;
printf("%d\t%d",*p1,**p2);
}