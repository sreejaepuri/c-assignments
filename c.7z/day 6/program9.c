#include<stdio.h>
int *fp1,*fp2,*fp3;
void main()
{
	int a,b,c;
	//int n=10;
	//int sum(int);
		
	int square(void);
	int cube(void);
	int sum(int *,int *);
	clrscr();
	a=square();
	printf("\nsquare ...:%d",a);
	b=cube();
	printf("\ncube...:%d",b);
	c=sum((&a),(&b));
	printf("\nthe ...:%d",c);
	//sum();	
}
int square()
{
	int square;
	int n=10;
	square=n*n;
	fp1=&square;
	printf("\nthe square of a number is...");
	return (*fp1);
}


int cube()
{
	int cube;
	int n=11;
	cube=n*n*n;
	fp2=&cube;
	printf("the cube of a number is...");
	//type (*fp2);
	return *(fp2);
}



int sum(int (*fp1),int (*fp2))
{
	int sum,a,b;
		fp3=&sum;
	
	sum=*fp1+*fp2;
	*fp3=sum;
	return (sum);
}
	