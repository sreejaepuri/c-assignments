#include<stdio.h>
#include<conio.h>
void main()
{
    int i;
	char name[5][30];
	char *ptr[10];
	
	
	for(i=0;i<10;i++)
	{
		scanf("%s",name+i);
	}
	for(i=0;i<10;i++)
	{
		ptr[i]=name[i];
	}
	
printf(" \nthe charecter arrays using pointers  ....");
	for(i=0;i<10;i++)
	{
		
		printf("\n%s",ptr[i]);
	}

}