#include<stdio.h>
void main()
{
	int i,j;
	char a[5][5];
	clrscr();
for(i=0;i<2;i++)
{
	j=0;
	for(j=0;j<2;)
	{
	flushall();
	scanf("%c",(*(a+i)+j));
	printf("\n%c%u",*(*(a+i)+j),*(a+i)+j);
	j++;
	}
	
}
printf("the charecter pointers are....");
for(i=0;i<2;i++)
{
	for(j=0;j<2;j++)
	{
		printf("\n%c%u",*(*(a+i)+j),*(a+i)+j);
//printf("\n%c",*(*(a+i)+j));
}
printf("\n");
}

}