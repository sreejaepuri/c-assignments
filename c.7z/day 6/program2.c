#include<stdio.h>
#include<conio.h>
void main()
{
int a[6],t,i;
clrscr();
printf("enter the numbers....");
for(i=0;i<12;i++)
{
	scanf("%d",&a[i]);

}
printf("\nthe numbers before swapping....");
for(i=0;i<12;i++)
{
	printf("\n%d",a[i]);


}
printf("\n the elements after swapping....");
//t=a;
for(i=0;i<12;i++)
{
	t=*(a+i);
	*(a+i)=*(a+(i+1));
	*(a+(i+1))=t;
	i++;
}
for(i=0;i<12;i++)
{
 printf("\n%d",*(a+i));

}
}