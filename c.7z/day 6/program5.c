#include<stdio.h>
#include<string.h>
void main()
{
	int i;
	char name[5][30];
	char *ptr[5];
	
	
	for(i=0;i<5;i++)
	{
		scanf("%s",name+i);
	}

	printf(" \nthe charecter arrays before exchange....");
	for(i=0;i<5;i++)
	{
		printf("\n%s",*(name+i));
	}
	for(i=0;i<5;i++)
	{
		ptr[i]=name[i];
	}
	
	ptr[0]=name[1];
	ptr[1]=name[0];
	
	printf(" \nthe charecter arrays after exchange....");
	
	
		//printf("\n%s",*(ptr+i));

	for(i=0;i<5;i++)
	{
		printf("\n%s",ptr[i]);
	}
}