#include<stdio.h>
#include<conio.h>

void main()
{
	int a[5],i,*p;
	p=a;
	for(i=0;i<5;i++)
	{
		printf("\n enter the number.....");
		scanf("%d",&a[i]);
		printf("a[%d]...%d",i,a[i]);
		
	}
	
	printf("\n the indirection to array pointer.....");
	for(i=0;i<5;i++)
	{
		
		printf("\na[%d]...%d",i,*(a+i));
		
	}
	printf("\n the number to pointer.....");	
	for(i=0;i<5;i++)
	{
		
		printf("\np[%d]...%d",i,p[i]);
		
	}
	for(i=0;i<5;i++)
	{
		//printf("\n the indirection to array pointer.....");
		printf("\na[%d]...%d",i,*(p+i));
		
	}
}