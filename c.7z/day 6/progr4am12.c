#include<stdio.h>
void main()
{
int i,id[10],id1;
char name[10];

for(i=0;i<10;i++)
{
printf("enter the names.....");
scanf("%s",&name[i]);
printf("enter the id.....");
scanf("%d",&id[i]);
}
printf("enter the id.....");
scanf("%d",&id1);

for(i=0;i<10;i++)
{
if(id[i]==id1)
{
printf("\n this id is present");
printf("\nid[%d]..%d",i,id[i]);
}
}
}