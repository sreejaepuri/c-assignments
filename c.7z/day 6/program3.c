#include<stdio.h>
void main()
{
	int a[5],i,t;
	clrscr();
	printf("\n the elements before swapping...");
	for(i=0;i<5;i++)
	{
	printf("\nenter the number...");
	flushall();
	scanf("%d",&a[i]);
	printf("\n%d",a[i]);
	}
	for(i=0;i<5;i++)
	{
	if(a[i]>a[i+1])
	{
		t=*(a+i);
	*(a+i)=*(a+(i+1));
	*(a+(i+1))=t;
	
	}
	}
	printf("\n the elements after swapping...");
for(i=0;i<5;i++)
	{
		printf("\n%d",a[i]);
}
}