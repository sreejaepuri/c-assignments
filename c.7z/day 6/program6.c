#include<stdio.h>
void main()
{
int a,ar[12];
void accept(void);
//void display(int [],int);
clrscr();

accept();

}
void accept()
{
	void display(int ar[],int);
    int ar[100];
	int a,n;
	int i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	scanf("\n%d",&ar[i]);
	}
	display(ar,n);
}
	
void display(int ar[],int n)
{
	int i;
	printf("the array is...%d",n);
	for(i=0;i<n;i++)
	{
	printf("\n%d",ar[i]);
	}
	printf("enter the size of array..%d",n);
}
	
	
	
