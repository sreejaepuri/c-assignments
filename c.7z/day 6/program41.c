#include<stdio.h>
void main()
{
	int i,j;
	char a[5][5];
	clrscr();
	for(i=0;i<5;i++)
{
	flushall();
	scanf("%s",(a+i));
}
	printf("the charecter pointers are....");
for(i=0;i<5;)
{
	
		printf("\n%s",*(a+i));
		
printf("\n%u",*(a+i));
i++;
}
	printf("\n\n");
}

