#include<stdio.h>
void main()
{
	int a=3,b=4;
	void exchange(int,int);
	clrscr();
	exchange(a,b);
}
	
	
	void exchange(int a,int b)
	{
	int *pa,*pb,t;
	printf("the no.s before swapping...");
	printf("\n%d\t%d",a,b);
	
	pa=&a;
	pb=&b;
	
	t=*pa;
	*pa=*pb;
	*pb=t;
	
	printf("\nthe no.s afterswapping...");
	printf("\n%d\t%d",*pa,*pb);
}
