#include<stdio.h>
#include<string.h>
void main()
{
	static int counta;
	static int countb;
	static int countc;
	static int countd;
	static int counte;
	int i,l;
	char s[50],ch;
	printf("enter the string....");
	scanf("%s",s);
	for(i=0;s[i]!='\0';i++)
	{
	if(s[i]=='a'||s[i]=='A')
	{
	counta=counta++;
	}
if(s[i]=='e'||s[i]=='E')
	{
	countb=countb++;
	}
	if(s[i]=='i'||s[i]=='I')
	{
		
		countc=countc++;
	}
	if(s[i]=='O'||s[i]=='o')
	{
		countd=countd++;
	}
if(s[i]=='u'||s[i]=='U')
{
	counte=counte++;
	
}
	}
	printf(" string is....  %s",s);
	printf("\n vowels a are ...%d",counta);
	printf("\n vowels e are ...%d",countb);
	printf("\n vowels i are ...%d",countc);
	printf("\n vowels o are ...%d",countd);
	printf("\n vowels u are ...%d",counte);
	}
