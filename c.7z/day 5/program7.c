#include<stdio.h>
void main()
{
int a[5],i;
for(i=0;i<=5;i++)
{
printf("\n\nenter the numbers...:");
scanf("%d",(a+i));
printf("\na[%d]=  %d",i,*(a+i));


}

}