#include<stdio.h>
void main()
{
	int rollno[7],marks[12],i;
	char names[12][12];
	for(i=0;i<=7;i++)
	{
		printf("\nenter the names...");
		scanf("%s",&names[i]);
		printf("\nenter the rollno[i]");
		scanf("%d",&rollno[i]);
		printf("\nenter the marks[i]");
		scanf("%d",&marks[i]);
		
		
	}
	for(i=0;i<=7za;i++)
	{
	printf("%s",names[i]);
	printf("%d",rollno[i]);
	printf("%d",marks[i]);
	if(marks[i]>=75&&marks[i]<=100)
	{
		printf("\n\n name[i]\t\trollno[i]\t\tmarks[i]%d grade a \t\t");
	}
	if(marks[i]>=40&&marks[i]<=75)
	{
		printf("\n name[i]\t\trollno[i]\t\tmarks[i]%d grade b\t\t");
	}
	if(marks[i]>=0&&marks[i]<=40)
	{
		printf("\n name[i]\t\trollno[i]\t\tmarks[i]%d grade c\t\t");
	}
	}


}