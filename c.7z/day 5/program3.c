//3. Accept two integers from the user and exchange their values with the help of pointers. Print the output in various stages of exchange.
#include<stdio.h>
void main()
{
int *p1,*p2,t;
int n1=3,n2=4;
printf("the values before exchange");
printf("\nn1=%d\t n2=%d",n1,n2);
p1=&n1;
p2=&n2;
 *p1=t;//*(&n1)=t;
n1=*p2;//&n2=n1;
n2=*p1;
printf("\n\nthe values after exchanged");
printf("\n n1=%d\t n2=%d",*p1,*p2);




}