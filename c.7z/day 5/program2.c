//2. Accept values for two integers from the user. Using pointers, find and print the greatest of these numbers. If both are equal, then print that they are equal.
#include<stdio.h>
void main()
{
	int user1,user2;
	int *p1,*p2;

	//for(i=0;i<=1;i++)
	
		printf("enter the 1st integers..");
		scanf("%d",&user1);
		
		printf("enter the  2ndintegers..");
		scanf("%d",&user2);
		
		printf("\nthe value of variable...:%d",user1);
		printf("\nthe value of variable...:%d",user2);
		
		p1=&user1;
		p2=&user2;
			
				//printf("\naddress of a variable...:%u",&user1);
		if(*p1>*p2)
		{
		printf("\nthe gretest no. is..%d",*p1);
		}
		else 
		{
		printf("\n\nthe greatest no. is..%d",*p2);
		}
		if(*p1==*p2)
		{
		printf("\nboth are equal");
		}	
}
