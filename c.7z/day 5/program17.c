#include<stdio.h>
void main()
	{
	int i;
	char ar[5][30];
	for(i=0;i<5;i++)
	{
	scanf("%s",ar[i]);
	}
	printf("the charecter arrays are....");
	for(i=0;i<5;i++)
	{
	printf("\n%s",ar[i]);
	}

	}