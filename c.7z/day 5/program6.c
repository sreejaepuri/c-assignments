
//6. Accept item code, ordered quantity and supplied qty from the user. Find the shortfall or excess supply and print the info, using pointers.
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char itemcode[10][12]={"pen","pencil","book","computers","mouse"};
int stock[10]={15,6,236,58,3};
int order_qty[12]={0,0,0,9,0},supplied_qty[12]={0,0,0,0,0};
void main()
{
	int option;
	
	char user1[21];
	
	//int shortfall,excess;
	
	
	void order(void);
	void supplier(void);
	
	
	
		
	printf("****menu****");
	printf("\n1.order qty");
	printf("\n2.supplier qty");
	printf("\n3.exit");
	printf("\nenter your choice..");
	scanf("%d",&option);
	switch(option)
	{
		case 1:
		order();
		break;
		case 2:
		supplier();
		break;
		case 3:
		exit(0);
		break;
		default:printf("\n invalid input");
	}
}
//}
	void order()
	{
		int i;
		char user1[12];
		extern int order_qty[12];
		int shortfall,s1;
	
		printf("\nenter the itemcode...");
		flushall();
		scanf("%s",user1);
		while(ch=='y')
		{
		for(i=0;i<=5;i++)
		{
			if(strcmp(user1,itemcode[i])==0)
			{
		//printf("%d",s1);//checks userid and itemcode
	//	if(s1==1)
		//{
			
//for(i=0;i<=5;i++)
		//{
			printf("\nitemcode[%d]=%s\t\tstock[%d]=%d",i,itemcode[i],i,stock[i]);//prints items
			printf("enter the order qty...");
			scanf("%d",&order_qty[i]);
		
		if(order_qty[i]>(*(stock+i)))
		{
			shortfall=order_qty[i]-stock[i];
			//printf("i=%d shortfall address..:%u",i,(shortfall+i));
			printf("shortfall..:%d",shortfall);
			//printf("i=%d \titemcode=%s\tstock=%d\t\t",i,itemcode+i,*(stock+i));
			
		}
		else
		{
			//if(order_qty[i]<*(stock[i]+i))
		//{
			*(stock+i)=stock[i]-order_qty[i];
			//printf("address..:%u",(shortfall+i));
			//printf("\nshortfall..:%d",*(shortfall+i));
			printf("\nthe order is accepted" );
			printf("\n\titemcode=%s\tstock=%d\t\t",itemcode+i,*(stock+i));
		}
		}
		

	}
		}
	printf("do u want to continue(y,n)");
	scanf("%c",&ch);
}
}
void supplier()
{
	int i;
		char user1[12];
		extern int order_qty[12];
		int shortfall,s1;
	
		printf("\nenter the itemcode...");
		flushall();
		scanf("%s",user1);
		while(ch=='y')
		{
		for(i=0;i<=5;i++)
		{
			if(strcmp(user1,itemcode[i])==0)
			{
		//printf("%d",s1);//checks userid and itemcode
	//	if(s1==1)
		//{
			
//for(i=0;i<=5;i++)
		//{
			printf("\nitemcode[%d]=%s\t\tstock[%d]=%d",i,itemcode[i],i,stock[i]);//prints items
			printf("enter the order qty...");
			scanf("%d",&order_qty[i]);
		
		if(order_qty[i]>(*(stock+i)))
		{
			shortfall=order_qty[i]-stock[i];
			//printf("i=%d shortfall address..:%u",i,(shortfall+i));
			printf("shortfall..:%d",shortfall);
			//printf("i=%d \titemcode=%s\tstock=%d\t\t",i,itemcode+i,*(stock+i));
			
		}
		else
		{
			//if(order_qty[i]<*(stock[i]+i))
		//{
			*(stock+i)=stock[i]-order_qty[i];
			//printf("address..:%u",(shortfall+i));
			//printf("\nshortfall..:%d",*(shortfall+i));
			printf("\nthe order is accepted" );
			printf("the supplier qty is...:");
			printf("\n\titemcode=%s\tstock=%d\t\t",itemcode+i,*(stock+i));
		}
		}
	}
		}
	printf("do u want to continue(y,n)");
	scanf("%c",&ch);
}
void exit()
{
	exit(0);
}		
		
		
	

	



	