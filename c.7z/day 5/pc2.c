#include<stdio.h>
void main()
{
int n=123455;
printf("%d ,%3d,%7d",n,n,n);
for (i=0; i <4; i++)
	{
		printf("\n %5d %10u %10d", i, no+i, *(no+i));
	}


}