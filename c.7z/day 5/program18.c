#include<stdio.h>
void main()

{
	int deposit[12],i;
	int balnce[12]={400,6230,4012,300,23500};
	printf("\n the blnce of accounts are: ");
	for(i=0;i<12;i++)
	{
	printf("\n%d",balnce[i]);
	}

	for(i=0;i<12;i++)
	{
	printf("enter the deposit...");
	scanf("%d",&deposit[i]);
	balnce[i]=balnce[i]+deposit[i];
	}
	for(i=0;i<12;i++)
	{
	printf("\nbalance...%d",balnce[i]);
	}
}