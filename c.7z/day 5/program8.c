#include<stdio.h>
void main()
{
int a[6],i,j;
for(i=0;i<=5;i++)
{
	a[i]=i;
	printf("\nthe array before initialization....:");
	printf("a[%d]=%d",i,a[i]);
}
for(j=0;j<=5;j++)
{
	
	*(a+i)=j;
	printf("\n\nthe array before initialization....:");
	printf("a[%d]=%d",j,*(a+j));
}
}
