#include<stdio.h>
void main()
{
int product[12][12],i,j;
printf("\n enter the details...");
for(i=0;i<10;i++)
{
	for(j=0;j<=1;j++)
	{
		scanf("%d",&product[i][j]);
		//printf("%d",product[i][j]);
	}

}
printf("**********");
printf("prodcode\t\t\tsales"); 
for(i=0;i<10;i++)
{
	for(j=0;j<=1;j++)
	{
		printf("\n%d",product[i][j]);
	}
	printf("\n");

}
}