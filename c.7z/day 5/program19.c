#include<stdio.h>
#include<string.h>
void main()
{
	int i;
	char s[12];
	printf("\nenter a string...");
	flushall();
	scanf("%s",&s);
	for(i=0;s[i]!='\0';i++)
	{
	if(s[i]=='.')
	{
		//strreplace(., );
	s[i]=' ';	
	}
	}
    printf("%s",s);
}