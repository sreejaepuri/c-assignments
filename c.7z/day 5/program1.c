//1. Accept values for two integers from the user. Store them in two variables. Print the address of these variables. Print the value using the variable name as well as using pointer indirection. Using pointers, increment the values of these variables by twice  their current value and print.
#include<stdio.h>
void main()
{
	int user1,user2,i;
	int *ptr1,*ptr2;
	static int count1;
	static int count2;

	printf("enter the 1st integers");
	scanf("%d",&user1);

	printf("enter the 2nd integers");
	scanf("%d",&user2);
	printf("\nthe value of variable...:%d",user1);
	printf("\naddress of a variable...:%u",&user1);
	printf("\nthe value of variable...:%d",user2);
	printf("\naddress of a variable...:%u",&user2);
	ptr1=&user1;
	ptr2=&user2;
	for(i=1;i<=2;i++)
	{
		user1=*ptr1++;
		user2=*ptr2++;
		
	}
	
	printf("\n\nthe value of variable...:%d",user1);
	printf("\naddress of a variable...:%u",&user1);
	
	printf("\n\nthe value of variable...:%d",user2);
	printf("\naddress of a variable...:%u",&user2);
	
	printf("\n\nthe value of 1stpointer variable...:%d",*ptr1);
	printf("\nthe value  of 2ndpointer  variable...:%d",*ptr2);
	
	printf("\n\nthe address of pointer variable...:%u",ptr1);
	printf("\nthe address of pointer variable...:%u",ptr2);
	
}

