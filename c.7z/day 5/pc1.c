# include <stdio.h>

main()
{
	int i;
	int no[4]={ 11, 14, 19, 26 };
	int *pno;
	no[2]=pno;
	printf("pno =%d",pno);
	for (i=0; i <4; i++)
	{
		printf("\n %5d %10u %10d", i, no+i, *(no+i));
	}

}