#include<stdio.h>
void main()
{
	int i;
	static float j=3;
	float a[12];
	for(i=0;i<=6;i++)
	{
	
	*(a+i)=j;
	j=j+5;
	printf("\n%f",*(a+i));
	}


}