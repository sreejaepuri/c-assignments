#include<stdio.h>
void greeting(char [],char);
void main()
{
	char ch1[12],ch2;
	void accept(void);
	
	clrscr();
	accept();
	

}
	void accept()
	{
		int i;
		//void greeting(char [],char);
			
		char ch1[12],ch2;
		printf("enter the name....");
		scanf("%s",ch1);
		printf("enter the gender(m/f)...");
		flushall(); 
		scanf("%c",&ch2);
		greeting(ch1,ch2); 
	
	}
	void greeting(char ch1[],char ch2)
	{
		//int i;
		//char ch3;
		//char name;
		//name=&ch1;
		//ch3=&ch2;
		if((ch2)=='f')
		{
			//name+i)=ch1[i];//
			printf("WELCOME TO Ms.%s ",ch1);
		
		}
		if((ch2)=='m')
		{
			//*(name)=ch1[i];
			printf("WELCOME TO Mr.%s ",ch1);
		
		}
		
}
	
	