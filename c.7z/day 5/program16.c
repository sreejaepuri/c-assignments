#include<stdio.h>
void main()
{
	int old[8][2],i,j;
	for(i=0;i<=8;i++)
	{

	for(j=0;j<=1;j++)
	{
		printf("enter the house  numbers");
		scanf("%d",&old[i][j]);
	//printf("%d",old[i][j]);
	}
	}
		printf("****house numbers****");
		printf("\nold\t\t new");
		printf("\n");
	for(i=0;i<=8;i++)
	{
		if(old[i][j]==old[i][j+1])
		{
		//printf("old[i][j]=%d\t\t andold[i][j+1]=%d");
		printf("\n old and new both are equal..");
			
		}

	for(j=0;j<=1;j++)
	{
		
		printf("%d\t\t",old[i][j]);
		
	}
	printf("\n");
	
	
	}
}