#include<stdio.h>
void main()
{
int i,no[5],sum1=0,sum2=0;
int *pno,*p1,*p2;
	//int no[4]={ 11, 14, 19, 26 };
	
	pno=no;
	//printf("\n Using Arrayname as pointer");
	//printf("\n\n ELEMENT   ADDRESS     VALUE");
for (i=0; i <=5; i++)
	{
		printf("\nenter the elements..:");
		scanf("%d",&no[i]);
			printf("\n %5d.%10u %10d", i, no+i, *(no+i));
		}
		printf("\n\nUsing a pointer to the Array");
		printf("\n\n ELEMENT   ADDRESS     VALUE");

		for (i=0; i <=5; i++)
		{
			printf("\n %5d %10u %10d", i, pno, *(pno));
			pno=pno+1;
		
		p1=pno+1;
		p2=pno+2;
	if(*(no+i)%2==0)
	{
		sum1=sum1+*(no+i);
		//(no+1)=(no+i)+(no+1);
		
	}
	else
	{
		sum2=sum2+*(no+i);
		//(no+2)=(no+i)+(no+2);
		

	}
	}
	p1=&sum1;
	p2=&sum2;
			printf("\neven sum=%d",*p1);
			printf("\nodd sum=%d",*p2);



	}