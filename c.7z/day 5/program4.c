//4. Accept five numbers and store them in suitable variables. Compute the sum of odd numbers and even numbers separately and print the result. Use pointers all the way
#include<stdio.h>
 main()
{
	int n,i;
	static int odd_sum;
	static int even_sum;
	int *P1,*p2;
	for(i=0;i<=5;i++)
	{
		printf("\nenter the number....");
		scanf("%d",&n);
		printf("\nn=%d",n);
		if(n%2==0)
		{
			even_sum+=n;
			
		}
		else
		{

			odd_sum+=n;
			
		}
			
	}
	p2=&odd_sum;
	p1=&evensum;
			printf("\nsum of even nos....%d",*p1);
			printf("\nsum of odd nos....%d",*p2);
}