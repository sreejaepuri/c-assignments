#include<stdio.h>
void main()
{
char ch[12]={'a','e','i','u','o','A','E','I','O','U'};
char a[12];
int i;
for(i=0;i<10;i++)
{
printf("\na[%d]=%c",i,ch[i]);
}
}