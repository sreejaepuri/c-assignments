#include<stdio.h>
#include<string.h>
void main()
{
	int i,j;
	char c1[5][6];
	for(i=0;i<5;i++)
	{
		//for(j=0;j<6;j++);
		//{
	scanf("%s",c1[i]);
		//}
	}
	for(i=0;i<6;i++)
	{
		
	printf("\n%s",*(c1+i));
	}
	
}