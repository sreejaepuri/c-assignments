#include<stdio.h>
void main()
{
	int a[10],i,t;
	//printf("enter the numbers");
	for(i=0;i<=10;i++)
	{
		printf("\nenter the number....");
	scanf("%d",&a[i]);
	}
	for(i=0;i<=10;i=i++)
	{
	printf("a[%d]=%d",i,a[i]);
	a[i]=a[i]+a[i+1];
	a[i+i]=a[i]-a[i+1];
	a[i]=a[i]-a[i+1];
	printf("\n%d ",a[i]);
	}
	//for(i=0;i<=10;i++)
		
	

}