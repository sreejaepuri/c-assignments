#include<stdio.h>
void main()
{

	int no[5],i,m1,uid;
	char name[12][30];
	float marks[5];
	for(i=0;i<5;)
	{
	printf("\nenter the student name and no and marks....");
	scanf("%d %s %f",&no[i],name[i],&marks[i]);
	i++;
	}
	printf("the no of marks before updation....");
	for(i=0;i<5;i++)
	{
	printf("%d\n%s\n%f",no[i],name[i],marks[i]);
	}
	printf("\nenter the student no. you want to improve....");
	scanf("%d",&uid);
for(i=0;i<5;i++)
{
	if(uid==no[i])
	{
	printf("enter the no. of marks to add");
	scanf("%d",&m1);
	marks[i]=m1+marks[i];
	printf("%d\n%s\n%f",no[i],name[i],marks[i]);
	}
}
}
