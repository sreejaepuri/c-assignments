#include<stdio.h>
#include<math.h>
	void main()
	{
	int l1=10,l2=6,l3=4,a,i,staff1=4,staff2=5,staff3=1;
	char ch;
	printf("\nstaff1=%d",staff1);
	printf("\nstaff2=%d",staff2);
	printf("\nstaff3=%d",staff3);
	/*for(i=0;i<10;i++)
	{
	scanf("%d",staff1[i]);
	}
	for(i=0;i<6;i++)
	{
	scanf("%d",staff2[i]);
	}
	for(i=0;i<4;i++)
	{
	scanf("%d",staff3[i]);
	}*/
	printf("\nenter you choice to relocate(y|n)");
	scanf("%c",&ch);
	while(ch=='y')
	{
		printf("**** menu***");
		printf("\n1.l1tol2");
		printf("\n2.l1tol3");
		printf("\n3.l2tol1");
		printf("\n4.l2tol3");
		printf("\n5.l3tol1");
		printf("\n6.l3tol2");
		printf("\nchoose location your option");

		scanf("%d",&a);
		switch(a)
		{
			case 1:
			printf("\n1.l1tol2");
				staff2=staff2++;
				staff1=staff1--;
				if(staff2<=l2)
				{
				printf(" you are successfully relocatedat l1 location");
				printf("staff1=%d",staff1);
				}
				else
				{
				printf(" you are not successfully relocated l1 location");
				}
				break;
			
			case 2:
			printf("\n2.l1tol3");
				staff1=staff1-1;
				staff3=staff3+1;
				if(staff3<=l3)
				{
				printf(" you are successfully relocated l1 location");
				printf("staff1=%d",staff1);
				}
				else
				{
				printf(" you are not successfully relocated l1 location");
				}
				break;
			case 3:
				staff2=staff2-1;
				staff1=staff1+1;
				if(staff1<=l1)
				{
				printf(" you are successfully relocated l2 location");
				printf("staff2=%d",staff2);
				}
				else
				{
				printf(" you are not successfully relocated l2 location");
				}
				break;
			case 4:
				staff2=staff2-1;
				staff1=staff1+1;
				if(staff3<=l3)
				{
				printf(" you are successfully relocated l2 location");
				printf("staff2=%d",staff2);
				}
				else
				{
				printf(" you are not successfully relocated l2 location");
				}
				break;
			case 5:
				staff3=staff3-1;
				staff1=staff1+1;
				if(staff1<=l1)
				{
				printf(" you are successfully relocated l3 location");
				printf("staff3=%d",staff3);
				}
				else
				{
				printf(" you are not successfully relocated l3 location");
				}
				break;
			case 6:
				staff3=staff3-1;
				staff2=staff2+1;
				if(staff2<=l2)
				{
				printf(" you are successfully relocated");
				printf("staff3=%d",staff3);
				}
				else
				{
				printf(" you are not successfully relocated");
				}
				break;
			default:
				printf(" you are not successfully relocated");
				
				
	}
	printf("\n do you want to continue(y|n)");
	flushall();
	scanf("%c",&ch);
	//
	}
}