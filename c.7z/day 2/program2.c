#include<stdio.h>
void main()
{
printf("student_name\t\tsubjects\t\tmarks");
printf("\n srija	\t\tmaths	\t\t50");
printf("\n srij		\tscience	\t\t50");
printf("\n sri		\tsanskrit\t\t50");
printf("\n sr		\tphysics	\t\t50");
printf("\n s		\tchemistry	\t50");
}