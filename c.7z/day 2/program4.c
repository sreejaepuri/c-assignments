#include<stdio.h>
void main()
{
int a,b;
printf("enter no are :");
scanf("%d %d",&a,&b);
a=a+b;
b=a-b;
a=a-b;
printf("after interchanging no are %d %d",a,b);



}