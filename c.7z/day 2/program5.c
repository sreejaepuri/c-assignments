#include<stdio.h>
void main()
{
int a=1,b=0;
if(a==0&b==0)
{
printf("both are zero");
}
else
{
printf("one variable is zero");
}

}
