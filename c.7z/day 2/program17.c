#include<stdio.h>
#include<math.h>
#include<conio.h>
void main()
{
int init=1,i;
printf(" the money u have  on nov 1:%d",init);
for(i=1;i<=29;i++)
{
	init[i]=init[i-1]*2;
}
printf("\n");

printf("\n\nthe money you have on dec 1 is:%d",init[29]);

}