#include<stdio.h>
void main()
{
int i,b;
printf(" enteer the number");
scanf("%d",&b);
for(i=0;i<=12;i++)
{
printf("\n(%d*(%d))=%d",i,b,(i*b));
}
printf("\n");
}