
//16.	Accept  2 numbers, accept operation add, mult, subt, divide. Perform the chosen operation and print the operands, operation and the result. Use  loop (6 iterations) and switch . If any one of the operands is 0, skip that iteration. Or if it is -5, exit the program. All cases print the values and messages in a clear manner.
#include<stdio.h>
void main()
{
	char ch;
	int n1,n2 ,choice;
	printf("enter the nos :");
	scanf("%d %d",&n1,&n2);
	do
	{
		if(n1==0||n2==0)
		{
			continue;
		}
		if(n1<0||n2<0)
		{
		exit(0);

		}
		printf("\n ******menu******..");
	 	printf("\n 1.addition...");
		printf("\n 2.subtraction...");
		printf("\n 3.multiplication...");
		printf("\n 4.division...");
		printf("enter your choice");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:n1=n1+n2;
					printf("\nthe addition of numbers is...:%d",n1);
					break;
			case 2:n1=n1+n2;
					printf("\nthe subtractionof nums is...:%d",n1);
					break;
			case 3:n1=((float)n1*n2);
					printf("\nthe multiplication of numbers is...:%d",n1);
					break;
			case 4:n1=n1/n2;
					printf("\nthe division of numbers is...:%d",n1);
					break;
			default:printf("all operations will be performed..");

		}
		printf("do you want to continue(y/n)");
		flushall();
		
		scanf("%c",&ch);
	}
	while(ch=='y');

	}