#include<stdio.h>
void main()
{
int a[5],i,sum=0;
for(i=0;i<=4;i++)
{
	printf(" enter the number");
	scanf("%d",&a[i]);
	
sum=sum+a[i];

printf(" number=%d\t sum=%d",a[i],sum);
}
printf(" \tsum=%d",sum);

printf("\n");
}