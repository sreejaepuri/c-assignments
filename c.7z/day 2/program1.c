#include<stdio.h>
void main()
{
	int i=1,j;
	char name[5],address[5],ad1[5],ad2[5];

	for(i=1;i<=5;i++)
	{
	printf("\nenter the name ");
	scanf("%s",&name);
	printf("\n");
	printf("\n enter the address");
	scanf("%s",&address);
	scanf("%s",&ad1);
	scanf("%s",&ad2);
	printf(" \n name=%s\t \naddress=%s \n\t%s \n\t%s",name,address,ad1,ad2);
	}
	printf("\n");


}