#include<stdio.h>
void main()
{
int a=2,b=4;
printf("%d",a++ + ++b);
a=b=1;
printf("\n%d",++a + b++);
}