#include<stdio.h>
#include<conio.h>

void main()
{ 
int i,a[10],total=0;
//float avg=0;
clrscr();
for(i=1;i<=10;i++)
{
printf("\nEnter a numbers");
scanf("%d",&a[i]);
total=total+a[i];
printf("tne number is :%d",a[i]);
}

printf("\ntotal=%d avg=%f",total,(total/(10.0)));

}