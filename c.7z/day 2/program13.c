#include<stdio.h>
void main()
{
int i,a[23 ];
for(i=0;i<=12;i++)
{
printf("\n((%d*8)=%d",i,(i*8));
}
printf("\n");
}