#include<stdio.h>
void main()
{
int b;
char ch='y';

while(ch!='N')	
  {
	  printf(" enter the number");
   scanf("%d",&b);
	if(b%2==0)
	{	
printf(" it is even number");
    }
	else 
	{
		printf("it is a odd number");
	}
	printf(" enter a charecter(Y/N)");
	flushall();
scanf("%c" ,&ch);
  }
   }