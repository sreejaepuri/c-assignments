#include<stdio.h>
  void main()
{
int a=10,b=10;

printf("\na==b=%d",(a==b));
printf("\na>b=%d",(a>b));//for equql nos it shows zero
printf("\na<b=%d",(a<b));
}