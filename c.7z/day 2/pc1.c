#include<stdio.h>

main()
{
	line();
	printf("\t WELCOME ");
	line();
}

line()
{
	printf("\n************************\n");
}
