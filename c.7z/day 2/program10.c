#include<stdio.h>
void main()
{
int test=3;
printf("%d\t%d",test++,++test);
printf("\n%d\t%d",++test,test++);//performing preecedence rules
}