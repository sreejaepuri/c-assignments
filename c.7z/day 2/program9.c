#include<stdio.h>
void main()
{
int bookcount=1,result=2;
result=++bookcount;
printf("%d\t%d",bookcount,result);
result=0;
bookcount=0;
result=bookcount++;
printf("\n%d\t%d",bookcount,result);
}