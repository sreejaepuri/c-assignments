	#include<stdio.h>
	#include<conio.h>
	#include<math.h>
	void main()
	{
		int partno[5],i,increase_percent[5];
		float newprice[5],oldprice[5];
		for(i=0;i<=5;i++)
		{
		printf("\nenter the part number");
		scanf("%d",&partno[i]);
		printf("%d",partno[i]);
		}
		for(i=0;i<=5;i++)
		{
			if(partno[i]==99)
			{
			break;
			}
			else if(partno[i]==999)
			{

			continue;
			}
			else
			{
			printf("\nenter the old price..");
			scanf("%f",&oldprice[i]);
			printf("\nenter the percent increse");
			scanf("%d",&increase_percent[i]);
			//newprice=((( increase_percent/100)*(oldprice))+oldprice);
			newprice[i]=(oldprice[i])+(float)(oldprice[i]*((float)increase_percent[i]/100));
			printf("\nenter the newprice=%f",newprice[i]);

			}
		}
		for(i=0;i<=5;i++)
		{
				printf(" \npartno =%d\t \t oldprice=%f\t \tnew price=%f",partno[i],oldprice[i],newprice[i]);
		
			
		}
	}
	