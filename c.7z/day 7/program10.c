#include<stdio.h>

struct car
{
	
	int year;
	char model[12];
		
	struct engine 
	{
		char brand[12];
		int serial_no;
		
	}e;
	};
	void main()
	{
		struct car c;
	struct car *p;
	p=&c;
	printf("\nenter the car details.....");
	scanf("%d%s%d%s",&c.year,c.e.brand,&c.e.serial_no,&c.model);
	printf("\ the car details are.....");
	printf("\n\nyear...%d\nbrand.....%s\nserial no.....%d\nmodel.....%s",p->year,p->e.brand,p->e.serial_no,p->model);
}