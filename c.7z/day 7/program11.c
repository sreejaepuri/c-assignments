#include<stdio.h>
struct emp
{
int id,ba;
char name[12];
float da,allpercent,ded_amt,netsal,grossal;
};

void main()
{
	struct emp e[10];
	//struct emp *p;
	int i;
	void calfunction(struct emp []);
	
	for(i=0;i<10;i++)
	{
	printf("enter the emp details.....");
	scanf("%d %d %s %f %f %f",&e[i].id,&e[i].ba,e[i].name,&e[i].da,&e[i].allpercent,&e[i].ded_amt);
	}
	
	calfunction(e);
	printf("*******the pay roll*******");
	for(i=0;i<10;i++)
	{
	printf("\n%d \n%d \n%s \n%f \n%f \n%f",e[i].id,e[i].ba,e[i].name,e[i].da,e[i].allpercent,e[i].ded_amt);
	
	printf("\n");
	
	printf("%f \t%f",e[i].grossal,e[i].netsal);

	}
	
	
	
	
}
void calfunction(struct emp e[])
{
//int grosssal;
	int i;
	float netsal;
	for(i=0;i<10;i++)
	{
	//scanf("%d%f",&e[i].grossal,&e[i].netsal);
	e[i].grossal=e[i].ba+e[i].da+e[i].allpercent;
	e[i].netsal=e[i].grossal-e[i].ded_amt;
	
	//printf("%f",e[i].grossal);
	}
}





