#include<stdio.h>
struct library member
{
int member no;
int book_issue;
char name[12];
}



void main()
{
}