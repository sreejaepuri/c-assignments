#include<stdio.h>
#include<malloc.h>
struct item_master
{
	int itemcode;
	char name[12];
	float current_stock;
}i1[5];
void main()
{
	int i;
	float received_qty[5];
	
	void addstock(struct item_master i1,int);
	clrscr();
	 
	
//printf("the total qty i....%f",a);
	for(i=0;i<5;i++)
	{
		
		printf("\nenter the details of itemcode and name and current stock.....");
		flushall();
		scanf("%d %s %f",&i1[i].itemcode,i1[i].name,&i1[i].current_stock);
		//scanf("%d%f",&i1[i].itemcode,&i1[i].qty);
	
	}
	for(i=0;i<5;i++)
	{
	printf("enter the received quantity %d...",i);
	flushall();
	scanf("%f",&received_qty[i]);
	addstock(i1[i],received_qty[i]);//calling
	}

}
void addstock(struct item_master i1,int received_qty)
{
    int i;
//float current_stock;
	
	i1.current_stock=i1.current_stock+received_qty;
	printf("\nthe final stock is.....");
	printf("\n\n%d.itemcode=%d\nname.....%s\ncurrent_stock.....%f",i,i1.itemcode,i1.name,i1.current_stock);

}

