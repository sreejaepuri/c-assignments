#include<stdio.h>
struct emp 
{
	int empno;
	char name[12];
	float salary;
}e[5];
void main()
{
	int i;
		printf("\nenter the employee details.....");
	for(i=0;i<5;i++)
		{
		printf("\n enter the detals of %d.....",i);
		scanf("%d%s%f",&e[i].empno,&e[i].name,&e[i].salary);
		}
		
	for(i=0;i<5;i++)
		{
		printf("\n\nthe detals of %d.....",i);
		printf("\nempno....%d\nname....%s\nsalry....%f",e[i].empno,e[i].name,e[i].salary);
		}
}