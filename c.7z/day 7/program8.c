#include<stdio.h>
#include<conio.h>
struct item_master
{
	int itemcode;
	char name[12];
	float current_stock;
}i1[5];
void main()
{
	struct item_master *p1[5];
	int i;
	float received_qty[5];
	void addstock(struct item_master *[],float[]);
	clrscr();
	for(i=0;i<5;i++)
		p1[i]=&i1[i];
	
	 
	
//printf("the total qty i....%f",a);
	for(i=0;i<5;i++)
	{
		
		printf("\nenter the details of itemcode and name and current stock.....");
		flushall();
		scanf("%d %s %f",&p1[i]->itemcode,p1[i]->name,&p1[i]->current_stock);
		//scanf("%d%f",&i1[i].itemcode,&i1[i].qty);

		printf("\nenter the received quantity %d...",i);
		scanf("%f",&received_qty[i]);
		
	}
	addstock(p1,received_qty);//calling

}
void addstock(struct item_master *p1[],float received_qty[])
{
    int i;
//float current_stock;
	for(i=0;i<5;i++)
	{
		p1[i]->current_stock=p1[i]->current_stock+received_qty[i];
		printf("\nthe final stock is.....");
		printf("\n\n%d.itemcode=%d\nname.....%s\ncurrent_stock.....%f",i,p1[i]->itemcode,p1[i]->name,p1[i]->current_stock);
	}

}
