#include<stdio.h>
struct course
{
	int maxstudents,code;
	char title[5];
	struct date
	{
		int day,month,year;
	} d[5];
};
void main()
{
 int i;
 struct course c[5];
  struct course *p1;
 for(i=0;i<5;i++)
 {
	printf("\nenter the course details");
	scanf("%d%s%d%d%d%d",&c[i].code,c[i].title,&c[i].d[i].day,&c[i].d[i].month,&c[i].d[i].year,&c[i].maxstudents);
 }
 
	printf("\nthe course details.......");
	//for(i=0;i<1;i++)
	//{
		p1=&c;
	//}

	for(i=0;i<5;i++)
	{
	printf("\n\ncode[%d]....%d\nname....%s\ndate....%d-%d-%d\nmax students%d",i,(p1+i)->code,(p1+i)->title,(p1+i)->d[i].day,(p1+i)->d[i].month,(p1+i)->d[i].year,(p1+i)->maxstudents);
	}
}