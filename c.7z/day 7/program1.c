#include<stdio.h>
	struct emp
	{
	int empno;
	char name[12];
	float salary;
	}
	main()
	{
	struct emp e;
	printf("enter the name and empnoand salary...");
	scanf("%s%d%f",e.name,&e.empno,&e.salary);
	printf("\nname....%s\nempno.....%d\nsalary.....%f",e.name,e.empno,e.salary);

}


