#include<stdio.h>
	struct emp
	{
	int empno;
	char name[12];
	float salary;
	};
	main()
	{
	struct emp e;
	struct emp *p1;

	printf("enter the name and empnoand salary...");
	scanf("%s%d%f",&e.name,&e.empno,&e.salary);
	p1=&e;
	printf("\nname....%s\nempno.....%d\nsalary.....%f",p1->name,p1->empno,p1->salary);

}