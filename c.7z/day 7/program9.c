#include<stdio.h>

struct car
{
	
	int year;
	char model[12];
		
	struct engine 
	{
		char brand[12];
		int serial_no;
		
	}e;
	}c;
	void main()
	{
	printf("\nenter the car details.....");
	scanf("%d%s%d%s",&c.year,c.e.brand,&c.e.serial_no,&c.model);
	printf("\ the car details are.....");
	printf("\n\nyear...%d\nbrand.....%s\nserial no.....%d\nmodel.....%s",c.year,c.e.brand,&c.e.serial_no,&c.model);
}