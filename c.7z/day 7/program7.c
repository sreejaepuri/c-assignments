#include<stdio.h>
#include<string.h>

struct item_master
{
int itemcode;
char name[12];
float current_stock;
};


void main()
{
	struct item_master i1={10,"sreeja",10.20};

	void asignment1(struct item_master);
	void asignment2(struct item_master);
	printf("\n\nDETAILS OF item master i2......");
	asignment1(i1);
	printf("\n\nDETAILS OF item master i3......");
	asignment2(i1);
}
void asignment1(struct item_master i1)
{
	struct item_master i2;
	strcpy(i2.name,i1.name);
	i2.itemcode=i1.itemcode;
	i2.current_stock=i1.current_stock;
	printf("\n%s\n%d\n%f",i2.name,i2.itemcode,i2.current_stock);
	
}
void asignment2(struct item_master i1)
{
	struct item_master i3;
	i3=i1;
	strcpy(i3.name,"mathi");
	printf("\n code of the item......%d",i3.itemcode);
	printf("\nName of the item : %s",i3.name);
	printf("\nstack of the item: Rs.%.2f",i3.current_stock);
}