#include<stdio.h>
#include<malloc.h>
struct item
{
int itemcode;
float qty;
};
void main()
{
	int i,x;
	struct item i1[5];
	struct item *p1;
	p1=&i1;
	x=(int*)malloc(10*sizeof(int));
	for(i=0;i<5;i++)
	{
	printf("\nenter the details of itemcode and item qty.....");
	scanf("%d%f",&i1[i].itemcode,&i1[i].qty);
	}
	printf("\n the details of item are.....");
	for(i=0;i<5;i++)
	{
	printf("\n%d.item code%....%d \n quantity.....%f",i,(p1+i)->itemcode,(p1+i)->qty);
 }
free(e);
}