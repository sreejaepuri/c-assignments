#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main()
{
	struct country
	{
	int code;
	int pop;
	}c;
FILE *fp;
char ch;
fp=fopen("COUNTRY.DAT","wb+");


if(fp==NULL)
	{
		puts("cant open a file.....");
		exit(0);

	}
	else
	{
	do
	{
		fflush(stdin);
		printf("\nenter country code....");
		scanf("%d",&c.code);
		printf("\nenter the population in crores.....");
		scanf("%d",&c.pop);
		fwrite(&c,sizeof(c),1,fp);
		printf("\ndo you want to continue(y/n)");
	ch=getche();
	}while(ch=='y');
	
	fclose(fp);
	}
}
