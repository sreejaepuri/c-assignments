#include<stdio.h>
#include<stdlib.h>
main()
{
	FILE *fp;
	char ch;
	fp=fopen("note1.txt","w");
	if(fp==NULL)
	{
		puts("cant open a file.....");
		exit(0);

	}
	printf("enter some charecters....");
	while(1)
	{
	ch=getc(stdin);
	if(ch!=EOF)
	{
	fputc(ch,fp);
	}
	else 
	break;
	}
fclose(fp);
}