# include <stdio.h>
# include <stdlib.h>
# include <conio.h>

void main()
{


	struct country
	{
		
		int  code,pop;
	};

	struct country c;

	char ch;

	FILE *fp;

	fp=fopen("COUNTRY.DAT", "rb");

	if (fp == NULL)
	{
	
		printf("\n File cannot be opened");
		exit(0);
	}
	else
	{
		printf("\n Want to continue(y/n):");;
		ch=getche();

		while (ch == 'y' ||  ch == 'Y')
		{

			
			fflush(stdin);

			printf("\n Enter the code &popultion in crores of the country:");
			scanf("%d %d", &c.code, &c.pop);
			printf("\n Want to continue(y/n):");
					ch=getche();
			fwrite(&c, sizeof(c), 1, fp);
			printf("\n\ncountry code....%dand population ..... %d", c.code, c.pop);
		}
				
	}
	
			
	

	fclose(fp);
}

