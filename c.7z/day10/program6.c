#include<stdio.h>
void main()
{
int b=5,c=4;
printf("\n%d",b|c);
printf("\n%d",b&c);
printf("\n%d",b^c);
printf("\n%d",~c);
}