#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	FILE *fp;
	char ch;
	fp=fopen("note1.txt","r");
	if(fp==NULL)
	{
		puts("cant open a file.....");
		exit(0);

	}
	//printf("enter some charecters....");
	while(1)
	{
		ch=fgetc(fp);
		if(ch==EOF)
		{
		fgetc(fp);
		}
		else 
		{
	printf("%c",ch);
		}
	}
fclose(fp);
}