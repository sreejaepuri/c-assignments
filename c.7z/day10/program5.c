# include <stdio.h>
# include <stdlib.h>
# include <conio.h>
struct student
	{
		
		int  no,marks;
		char name[12];
	};

void main()
{


	
	struct student s;

	char ch;

	FILE *fp;
	void add(struct student s);
	fp=fopen("STUDENT.DAT", "wb+");
	if (fp == NULL)
	{
	
		printf("\n File cannot be opened");
		exit(0);
	}
	else
	{
		printf("\n Want to continue(y/n):");;
		ch=getche();

		while (ch == 'y' ||  ch == 'Y')
		{

			
			fflush(stdin);

			printf("\n Enter the no and name and marks for student....:");
			scanf("%d %s %d", &s.no,s.name, &s.marks);
			printf("\n Want to continue(y/n):");
			ch=getche();
			fwrite(&s, sizeof(s), 1, fp);
			
			printf("\n.......the  student list ....\n%s\n%d\n%d",s.name,s.no,s.marks);
			add(s);
		}
				
	}
	
	fclose(fp);
}
void add(struct student s1)
{
	int m1;
	printf("enter the marks to add...");
	scanf("%d",&m1);
	s1.marks=s1.marks+m1;
	printf("\n\n.......the updated student list ....\n%s\n%d\n%d",s1.name,s1.no,s1.marks);
	
}

