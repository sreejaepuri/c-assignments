//5.	Write a function which accepts the item code and sales amount. The function will accumulate the total sales in a global variable.  In main(), within a while loop accept values from the user and call the function. When the loop exits, print the total in a formatted manner.
#include<stdio.h>
#include<conio.h>
int id1[12],i;
static int totalamt;
int amt[12];

void main()
{
	int t1;
	char ch='y';
	void itemcode(void);
	int total(int []);
	itemcode();
	
	
	printf("do u want to continue(y/n)");
	ch=getche();
	while(ch=='y')
	{
		itemcode();
		t1=total(amt);
		printf("total amt =%d",t1);
		
		printf("do u want to continue(y/n)");
		ch=getche();
	}
}
void itemcode()
{
	static int i;
	
	printf(" enter the item code...:");
	scanf("%d",&id1[i]);
	printf("\nenter the sales amunt ..:");
	scanf("%d",&amt[i]);
	i++;
	//printf("item code:%d",id1[i]);
	//printf("sales amt:%d",amt[i]);
	
}
int total(int amt[])
{ 
	totalamt=totalamt+amt[i];
	//printf("%d",total);
	return totalamt;
}
	
	
	
	
