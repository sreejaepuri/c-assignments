/*
3.	Write the following functions:
- one which accepts the pass mark, max mark and stores them in  global       variables
- one which accepts student no and marks obtained  and */
#include<stdio.h>
 int marks;
 int pass,max;
 void main()
 {
	 void pass_marks(void);
	 void max_marks(void);
	 void details();
	 printf("enter the details..:");
	 
	 pass_marks();
	 max_marks();
	 details();
	
}
 void pass_marks()
{
	
	printf("enter the pass marks..:");
	scanf("%d",&pass);
	printf(" the pass marks..:%d",pass);
}
void max_marks()
{
	printf("enter the max marks...");
	scanf("%d",&max);
}
void details()
{
	int marks;
	printf("enter the marks...");
	scanf("%d",&marks);
	//flushall();
	if(marks>0&&marks<max)
	{
		printf("he is passed the exam..");
		
	}
	else{
		printf("he failed th exam");
	}
		
		
	}
	

	
 