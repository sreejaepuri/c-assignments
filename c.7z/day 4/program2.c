//2.	Write a C program which maintains stock in  a global variable. Write two functions, one for receiving materials and the other for issuing materials. These will update the stock. Print the stock from main().


#include<stdio.h>
//extern int stock;
 main()
{
	
	 int current_stock=123,r;
	int total,received;
	int receieve_stock1(int);
	int issue_stock1();
	 
	printf("enter the current stock..:%d",current_stock);
	//scanf("%d",&current_stock);
 
	received=receive_stock1(current_stock);
	printf("stock+received=%d",received);
	total=issue_stock1(received);
	printf("updated total stock=%d",total);
	return 0;
}

int receive_stock1(int current_stock)
{
	char ch;
	int stock1;
	//static int count;
	int r;
	
	//count++;
	printf("\n enter the no to receive materials...");
	scanf("%d",&r);
    stock1=r+current_stock;

	//printf(" \nthe no.of times received...%d",count);
	
	return stock1;
}


int issue_stock1(int stock)
{

	 int n;

	printf("\nenter the no.of materials to issue..");
	scanf("%d",&n);
	stock=stock-n;

return stock;
}

