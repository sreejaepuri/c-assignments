//6.	Write an application which stores the balance of 5 savings accounts,
 //accepts deposit_amt, adds to the respective balance and prints the accumulated balance
#include<stdio.h>
#include<conio.h>
//int total_balance;
int depositamt;
int savings[12];
int balance[23];
int a[12];

void main()
{
	int i;
	int user;
	//static int count;
	
	
	void bank(void);
	void deposit(void);
	void accumulatedbal(int);

	bank();
	printf(" enter account no to which you have to deposit");
	scanf("%d",&user);
	for(i=0;i<2;i++)
	{
		if(a[i]==user)
		{
			printf("you are a valid user..");
			deposit();
			accumulatedbal(i);
		}
	}


}
void bank()
{

int i;

		
		
	for(i=0;i<2;i++)
	{
		printf(" enter account no.s");
		scanf("%d",&a[i]);
		printf("enter the balance of saving acc..:");
		scanf("%d",&savings[i]);
		
	}
}
void deposit()
{

		printf("enter amt to deposit");
		scanf("%d",&depositamt);
	printf("enter amt to deposit %d",depositamt);
	
}
void accumulatedbal(int i)
{
	savings[i]=savings[i]+depositamt;
	printf("balnce..:%d",savings[i]);
}
	
	
