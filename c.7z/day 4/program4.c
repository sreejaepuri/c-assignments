//4.	 Write a function which accepts account number, balance and withdrawal amount and returns the new balance. If the withdrawal is more than 3 times for the same account, then deduct an additional amount of  Rs.100. In main() accept values from the user and call the function. Print the results. Use a while loop to accept values and call the function till the user enters 'N'.
#include<stdio.h>
#include<conio.h>
#include<string.h>

 float bal[12];
 int acc[12];
void main()
{
	char ch,ch3;
	//float withdraw2,withdraw;
	int choice,count=0,i,ch1;
	void accept(void);
	void withdrawl(float []);
	clrscr();
	

	accept();
	withdrawl(bal);
	printf("do u want to continue(y/n)");
	flushall();
	scanf("%c",&ch);
	//l1:
	//{
	while(ch=='y')
	{	
		printf("\n ****menu****");
		printf("\n 1.enquiry.");
		printf("\n 2.withdrawl.");
		printf("\n 3.exit.");
		printf("enter ur choice");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				printf(" enter your account no.");
				
				scanf("%d",&ch1);
				for(i=1;i<2;i++)
				{
					count++;
					if(ch1==acc[i])
					{
						printf("you are a valid user");
						printf("%f",bal[i]);
						break;
						
					}
					if(count == 10)
					{
						printf(" invalid account number");
						break;
					}
				}
				break;
		 
			case 2:
		
				printf(" enter your account no.");
				flushall();
				scanf("%d",&ch1);
				for(i=0;i<2;i++)
				{
					count++;
					if(ch1==acc[i])
					{
						printf("%f",bal[i]);
						
					}
					if(count == 10)
					{
						printf(" invalid account number");
						exit(0);
					}
				}
				withdrawl(bal);
				break;
			
			case 3:
				exit(0);
	
		
		}
		printf("do u want to continue(y/n)");
	}
	
		scanf("%d",&ch);	
		

	}

	
void accept()
{
	int i;
	
	
	for(i=1;i<=2;i++)
	{
		printf("\nenter the account number..");
		scanf("%d",&acc[i]);
		printf("\nenter the    balance");
		scanf("%f",&bal[i]);
		//printf("the accountno. is..:%d",acc[i]);
		//printf(" the balance is ...:%f",bal[i]);
	}
}
void withdrawl(float bal[])
{  
	static count;
	int i;
	char ch;
	float withdraw;
	//printf("are you sure to withdrdawl(y/n)...");
	//scanf("%c",&ch);
	printf("enter  withdraw amount");
	scanf("%f",&withdraw);
	count++;
	for(i=0;i<2;i++)
	{
	if(withdraw>bal[i])
				{
					printf("you can't withdraw");
					
				}
				
	bal[i]=bal[i]-withdraw;
	if(count==3)
	{
		bal[i]=bal[i]-100;
		
		
	}
	}
}
	printf("the withdrawl amount..:%d",withdraw);
	printf("the availiable bal...:%f",bal);
}