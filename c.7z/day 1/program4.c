#include<stdio.h>
#include<conio.h>
void main()
{
	char c1,c2,c3,c4,c5;
	printf("enter values");
	scanf("%c %c %c %c %c",&c1,&c2,&c3,&c4,&c5);
	printf("\nchar values :c1=%c c2=%c c3=%c c4=%c c5=%c",c1,c2,c3,c4,c5);


}