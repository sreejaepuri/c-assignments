#include<stdio.h>
void main()
{
	printf(" welcomes	lcomes to the user to c learning");
}