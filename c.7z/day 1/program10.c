#include<stdio.h>
void main()
{
	const int bonus_percent=56;
	bonus_percent+=6;
	printf("bonus_percennt =%d",bonus_percent);//cant modify const a value


}