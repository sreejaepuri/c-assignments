#include<stdio.h>
void main()
{
	int n2=2;
	float d,e,n1=5;
	d=n1/n2;
	printf("\n%f",d);
	e=n2/n1;
	printf("\n%f",e);
}