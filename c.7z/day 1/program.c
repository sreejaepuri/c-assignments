#include<stdio.h>

void main()
{
	int age,id;
	clrscr();
	printf("enter the  values age and id");
	scanf("%d%d",&age,&id);
	printf("age=%d id=%d",age,id);
}