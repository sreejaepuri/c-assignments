#include<stdio.h>
void main()
{
	int m1,m2,m3,m4,m5,t1,t2,t3,t4,t5;
	printf("enter the first number ");
	scanf("%d",&m1);
	t1=m1;
	printf("\nenter the second number");
	scanf("%d",&m2);
	t2=m2;
	m2=(m1*2)+m2;
	printf("\nenter the third value");
	scanf("%d",&m3);
	t3=m3;
	m3=((m2*3)+m3);
	printf("\nenter the fourth value");
	scanf("%d",&m4);
	t4 =m4;
	m4=(m3*4)+m4;
	printf("enter the fifth value");
	scanf("%d",&m5);
	t5=m5;
	m5=(m4*5)+m5;
	printf("values %d %d %d %d %d",t1,t2,t3,t4,t5);
	printf("values %d %d %d %d %d",m1,m2,m3,m4,m5);

}