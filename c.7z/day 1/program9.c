#include<stdio.h>
#include<conio.h>
void main()
{
	char *str1,*str2;
	scanf("%c",str1);
	printf("%c",str1)
	getch(str2);
	putchar(str2);
}