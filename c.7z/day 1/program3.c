#include<stdio.h>
#include<conio.h>
void main()
{
	int a;
	char b; 
	float c;
	 double d;
	 clrscr();
	 printf("%d%c%f%lf",a,b,c,d);
	 printf("  enter to intitialize variables ");
	 scanf("%d %c %f %lf",&a,&b,&c,&d);
	 printf("a=%d b=%c c=%f d=%lf",a,b,c,d);


getch();
}