#include<stdio.h>
#include<conio.h>
	void main()
	{
	char ch1,ch2,ch3; 
	clrscr();
	printf("enter the values");
	ch1=getch();
	putchar(ch1);
	printf("enter the values");
	ch2=getchar();
	putchar(ch2);
	flushall();
	printf("enter the values");
	ch3=getche();
	putchar(ch3);

}