#include<stdio.h>
void main()
{
	double m1,m2,m3,m4,m5,s1,s2,s3,s4,s5;
	int r1,r2;
	float total1,total2,avgid1,avgid2;
	printf("enter the marks and rollno");
	scanf("%lf%lf%lf%lf%lf%d",&m1,&m2,&m3,&m4,&m5,&r1);
	scanf("%lf%lf%lf%lf%lf%d",&s1,&s2,&s3,&s4,&s5,&r2);
	total1=m1+m2+m3+m4+m5;
	total2=s1+s2+s3+s4+s5;
	avgid1=total1/(2.0);
	avgid2=total2/(2.0);
	printf(" rollno=%d  total1=%d avgid1=%f",r1, total1,avgid1);
	printf(" rollno=%d  total2=%d avgid2=%f",r2, total2,avgid2);
}
