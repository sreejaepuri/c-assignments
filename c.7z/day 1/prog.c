#include <stdio.h>
#include <conio.h>

main()
{
	/* INPUT & OUTPUT STATEMENTS */

	/* Handling Character & String Data */

	char ch,ch1,ch2,str1[10],str2[10];
	clrscr();

	printf("Enter a value for ch ...:");
	scanf("%c", &ch);
	printf("The character is %c", ch);
	printf("\n\nEnter a value for ch1 ...:");
	flushall();	// Clears the Buffer
	ch1=getch();

	printf("\n\nEnter a value for ch2 ...:");
	ch2=getchar();
	putchar(ch2);

	printf("\n\nEnter a Muti-word String....");
	scanf("%s",str1);
	printf("\nString 1 = %s" ,str1);
	flushall();	// Clears the Buffer
	printf("\n\nEnter a Muti-word String....");
	gets(str2);
	puts(str2);
	printf("\nString 2 = %s" ,str2);
	getch();
}

