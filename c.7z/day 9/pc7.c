#include<stdio.h>
void main()
{
int a=5;
int b=2;
float result ;
result=a/b;
printf("%f",result);
}