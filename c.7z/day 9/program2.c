#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
struct employee
{
int empno;
char ename[12];
float salary;
struct employee *link;
}e;
int n,i;

void main()
{
	
	
	struct employee *head;
	void append(struct employee **q,struct employee);
	void display(struct employee *q);
	void total(struct employee *q);
	clrscr();
	head=NULL;
	printf("\n enter the total no.of emplyee");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	printf("\n enter the details....");
	scanf("%d %s %f",&e.empno,e.ename,&e.salary);
	append(&head,e);
	}
	printf("\n\n");
	display(head);
	//total(head);
}
void append(struct employee **q,struct employee tempemployee)
{
	struct employee *temp;
	struct employee *traverse;
	traverse=*q;
	temp=(struct employee *)malloc(sizeof(struct employee));
	temp->empno=tempemployee.empno;
	strcpy(temp->ename,tempemployee.ename);
	temp->salary=tempemployee.salary;
	if(traverse==NULL)
	{
		*q=temp;
	}
	else
	{
		while(traverse->link!=NULL)
		{
			traverse=traverse->link;
		}
		traverse->link=temp;
		
	}
}
void display(struct employee *q)
{
	float total=0;
	
	while(q!=NULL)
	{
		total=total+q->salary;
		printf("\n\n\neno is...%d",q->empno);
		printf("\nename is...%s",q->ename);
		printf("\nsalary is...%f",q->salary);
		printf("\ntotalsalary is...%f",total);
		q=q->link;
	}
	
	
}
