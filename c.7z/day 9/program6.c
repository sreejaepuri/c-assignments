//DELETING A NODE
#include<stdio.h>
#include<alloc.h>
#include<string.h>
#include<conio.h>
struct student
{
	int sno;
	char sname[12];
	float marks;
	struct student *link;
}s;
void main()
{
	struct student *head;
	int i,no;
	void append(struct student **q,struct student tempstudent);
	void display(struct student *q);
	void delete(struct student **q,int);
	//struct student *head;
	
	clrscr();
	
	head=NULL;
	for(i=0;i<4;i++)
	{
	printf("\n enter the studentno,student name,student marks.....");
	flushall();
	scanf("%d%s%f",&s.sno,s.sname,&s.marks);
	append(&head,s);
	}
	display(head);
	//printf("\n\n\");
	
	printf("enter the no. to delete");
	scanf("%d",&no);
	delete(&head,no);
	//printf("\n\n");
	display(head);

}
void append(struct student **q,struct student tempstudent)
{
	struct student *temp;
	struct student *traverse;
	traverse=*q;//pointing to head
	temp=(struct student *)malloc(sizeof(struct student));//memory allocation
	temp->sno=tempstudent.sno;
	//temp->sname=sname;
	strcpy(temp->sname,tempstudent.sname);
	temp->marks=tempstudent.marks;
	
	if(traverse==NULL)
	{
		*q=temp;//cpy total temp struct to value at traverse
		
	}
	else
	{
		while(traverse->link!=NULL)
		{
			traverse=traverse->link;
		}
		traverse->link=temp;
	}
}
void display(struct student *q)
{
	/* traverse the entire linked list */
	while (q != NULL)
	{
		printf("\n %d",q -> sno);
		printf("\n %s",q -> sname);
		printf("\n %f",q -> marks);
		q=q -> link;
	}
}
void  delete(struct student **q,int no)
{
	
	struct student *temp;
	struct student *traverse;
	int i,found=0;
	struct student *trap=NULL;
	traverse=*q;
	/*for(i=1;i<3;i++)
	{
		traverse=traverse->link;
		
	}
		temp = (struct student *)malloc(sizeof(struct student));
		/*temp->sno=sno;
		temp->name=name;
		temp->marks=marks;
		temp->sno=tempstudent.sno;
		strcpy(temp->sname,tempstudent.sname);
		temp->marks=tempstudent.marks;
		
		temp->link=traverse->link;
		traverse->link=temp;

	//display(*q);*/
	do
	{
		if(traverse->sno==no)
		{
			found=1;
			break;
		}
		else
		{
			trap=traverse;
			traverse=traverse->link;
		}
	}while(traverse!=NULL);
	if(found==0)
	{
		printf("\n element found....");
	}
else
{
	if(trap==NULL)
	{
		*q=traverse->link;
		free(traverse);
		
	}
	else
	{
		trap->link=traverse->link;
		free(traverse);
	}
}	
	temp=NULL;
}


