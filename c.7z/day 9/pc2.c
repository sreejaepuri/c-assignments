#include<stdio.h>
#include<conio.h>
#include "practice1.c"

	/* Demo for Bitwise OR operator */
	/* To put ON a particular bit */

void main()
{
 	int i=65,j;
	printf(" Before setting ON the 5th bit\n ");
	showbits(i);

	printf("\n\n Setting ON the 5th bit ");
	j= i|32;   // (2^5 = 32)

	printf("\n\n After setting ON the 5th bit\n ");
	showbits(j);
	printf("\n The value of j = %d ",j);
	getch();

}
