#include<stdio.h>
#include<alloc.h>
#include<string.h>
#include<conio.h>
struct student
{
	int sno;
	char sname[12];
	float marks;
	struct student *link;
}s;
void main()
{
	
	int i;
	void append(struct student **q,struct student tempstudent);
	void display(struct student *q);
	void  add(struct student **q,struct student tempstudent);
	struct student *head;
	
	clrscr();
	
	head=NULL;
	for(i=0;i<4;i++)
	{
	printf("\n enter the studentno,student name,student marks.....");
	flushall();
	scanf("%d%s%f",&s.sno,s.sname,&s.marks);
	append(&head,s);
	}
	
	printf("\n enter the studentno,student name,student marks.....");
	flushall();
	scanf("%d%s%f",&s.sno,s.sname,&s.marks);
	
	add(&head,s);
	//printf("\n no.of elments in the list=%d
	display(head);

}
void append(struct student **q,struct student tempstudent)
{
	struct student *temp;
	struct student *traverse;
	traverse=*q;//pointing to head
	temp=(struct student *)malloc(sizeof(struct student));//memory allocation
	temp->sno=tempstudent.sno;
	//temp->sname=sname;
	strcpy(temp->sname,tempstudent.sname);
	temp->marks=tempstudent.marks;
	
	if(traverse==NULL)
	{
		*q=temp;//cpy total temp struct to value at traverse
		
	}
	else
	{
		while(traverse->link!=NULL)
		{
			traverse=traverse->link;
		}
		traverse->link=temp;
	}
}
void display(struct student *q)
{
	/* traverse the entire linked list */
	while (q != NULL)
	{
		printf("\n %d",q -> sno);
		printf("\n %s",q -> sname);
		printf("\n %f",q -> marks);
		q=q -> link;
	}
}
void  add(struct student **q,struct student tempstudent)
{
	struct student *temp;
	struct student *traverse;
	int i;
	traverse=*q;
	for(i=1;i<3;i++)
	{
		traverse=traverse->link;
		
	}
		temp = (struct student *)malloc(sizeof(struct student));
		/*temp->sno=sno;
		temp->name=name;
		temp->marks=marks;*/
		temp->sno=tempstudent.sno;
		strcpy(temp->sname,tempstudent.sname);
		temp->marks=tempstudent.marks;
		
		temp->link=traverse->link;
		traverse->link=temp;

	//display(*q);
	free(temp);
	temp=NULL;
	
	
}


