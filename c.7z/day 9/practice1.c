#include<stdio.h>
void showbits(int n)
{
		int i, k, andmask;

		for (i=15; i >= 0; i--)
		{
				andmask=(1 << i);
				k=n&andmask;

				printf("%d",k?1:0);
		}
		getch();
}
