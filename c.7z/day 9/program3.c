#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
struct account
{
	int accno;
	char name[12];
	float balance;
	struct account *link;
}a;
void main()
{
	int n;
	static int i=0;
	
	struct account *head;
	void append(struct account **q,struct account);
	void display(struct account *q);
	clrscr();
	head=NULL;
	printf("\n enter the total no.of emplyee");
	flushall();
	scanf("%d",&n);

	while(i<n)
	{
	printf("\n enter the details....");
	scanf("%d %s %f",&a.accno,a.name,&a.balance);
	append(&head,a);
	i++;
	}
	printf("\n\n");
	display(head);

	
}
void append(struct account **q,struct account tempaccount)
{
	struct account *temp;
	struct account *traverse;
	traverse=*q;
	temp=(struct account *)malloc(sizeof(struct account));
	temp->accno=tempaccount.accno;
	strcpy(temp->name,tempaccount.name);
	temp->balance=tempaccount.balance;
	if(traverse==NULL)
	{
		*q=temp;
	}
	else
	{
		while(traverse->link!=NULL)
		{
			traverse=traverse->link;
		}
		traverse->link=temp;
		
	}
}
void display(struct account *q)
{
	float total=0;
	while(q!=NULL)
	{
		total=total+q->balance;
		printf("\n\n\naccno is...%d",q->accno);
		printf("\nname is...%s",q->name);
		printf("\nbalanceis...%f",q->balance);
	count++;
		q=q->link;
	}
		printf("\n\n\ntotal balances is...%f",total);
		//printf("\n\n\ntotal balances is...%f",count);
	
}