#include<stdio.h>
#include<conio.h>
#include "practice1.c"

	/* Demo for Bitwise XOR operator */
	/* To toggle a particular bit */

void main()
{
 	int i=65,j;
	printf(" Bit pattern of %d  ",i);
	showbits(i);

	printf("\n\n Toggling the 5th bit ");
	j= i^32;   // (2^5 = 32)

	printf("j=%d",j);
	printf("\n\n After toggling the 5th bit\n ") ;
	showbits(j);
}
