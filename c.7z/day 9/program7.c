#include<stdio.h>
#include<conio.h>
#include<alloc.h>
#include<string.h>
struct student
{
int sno;
char sname[12];
float marks;
struct student *link;
}s;
void main()
{
	struct student *head;
	int i,n1,marks1;
	float marks;
	
	void append(struct student **q,struct student);
	void display(struct student *q);
	void add(struct student **q);
	head=NULL;
	clrscr();
	
	for(i=0;i<5;i++)
	{
	printf("\n enter the studentno,student name,student marks.....");
	scanf("%d %s %f",&s.sno,s.sname,&s.marks);
	append(&head,s);
	//printf("\n no.of elments in the list=%d
	display(head);
	
	}
	
	add(&head);
	printf("\nthe list after updation");
	display(head);
}


void append(struct student **q,struct student tempstudent)
{
	struct student *temp;
	struct student *traverse;
	traverse=*q;//pointing to head
	temp=(struct student *)malloc(sizeof(struct student));//memory allocation
	temp->sno=tempstudent.sno;
	//temp->sname=sname;
	strcpy(temp->sname,tempstudent.sname);
	temp->marks=tempstudent.marks;
	
	if(traverse==NULL)
	{
		*q=temp;//cpoies total temp struct to value at traverse
		
	}
	else
	{
		while(traverse->link!=NULL)
		{
			traverse=traverse->link;
		}
		traverse->link=temp;
	}
}



void display(struct student *q)
{
	/* traverse the entire linked list */
	while (q != NULL)
	{
		printf("\n %d", q->sno);
		printf("\n %s", q->sname);
		printf("\n %f", q->marks);
		q=q -> link;
	}
}
void add(struct student **q)
{
	int found=0;
	int m1,n1,i;
	//struct student *temp;
	struct student *traverse;
	//struct student *trap=NULL;
	traverse=*q;//pointing to head
	printf("\n enter the studentno,and student marks.....");
		scanf("%d %d",&n1,&m1);
	do
	{
		
		if(traverse->sno==n1)
		{
			found=1;
			break;
		}
		else
		{
			traverse=traverse->link;
		
		//
		}
	}while(traverse!=NULL);
		if(found==1)
		{
			traverse->marks=m1;
		}
		else
		{
			printf("element is not found");
		}
}
/*else
{
	if(trap==NULL)
	{
		*q=traverse->link;
		free(traverse);
		
	}
	else
	{
		trap->link=traverse->link;
		free(traverse);
	}
}	
	//temp=NULL;*/
	



