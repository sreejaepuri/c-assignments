#include <stdio.h>
#include <conio.h>

			/* COMPILER CONTROL DIRECTIVES */

#define VGA


void main(void) 
{

#ifdef MONO

  printf("\n prossing logic for mono monitor");

#endif

#ifdef VGA

   printf("\n prossing logic for color monitor");

#endif
 
}
