	#include <stdio.h>
#include "practice.c"

void main()
{
	/*  Demo for Right Shift Operator */

	int i=19;
	int j,k;
	printf("\n Bit Pattern of %d is   ", i);		
	showbits(i);
	for (j=0; j<=3; j++)
	{
		k=i >> j;

		printf("\n %d right shift %d gives ", i,j);
		showbits(k);
	}
}

