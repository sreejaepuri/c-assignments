#include<stdio.h>
#include<stdlib.h>
void main(int a,int b)
{
	
int c,*c1;
//a=atoi(argv[1]);
//b=atoi(argv[2]);
c=a+b;
c1=&c;
printf("%d",*c1);
}