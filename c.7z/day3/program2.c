//2.	Write three functions add, subtract, divide and modulus. Each of these will accept two arguments, compute and return the result. In main(), accept values from the user and type of operation ( 1-add, 2- subtract, etc.,). Call 
//the appropriate function and print the result from main.
#include<stdio.h>
#include<conio.h>
int a1,s1,a2,s2,d1;
int d2,add,sub,mod;
void main()
{

float dm;

int add1(void);
int sub2(void);
int div_mod3(void);

add=add1();
printf("\nadd=%d",add);
sub=sub2();
printf("\n sub=%d",sub);
dm=div_mod3();
printf("\n%f",dm);
}

int add1()
{ 

printf("\nenter nos to add");
scanf("%d%d",&a1,&a2);
add=a1+a2;
return add;
}

int sub2()
{
	
printf("\nenter nos to subtract");
scanf("%d%d",&s1,&s2);
sub=s1-s2;
return sub;
}
int div_mod3()
{int dm;
float div;
printf("\nenter nos to division");
scanf("%d%d",&d1,&d2);
div=d1/d2;
printf("division :=%f",div);
dm=d1%d2;
return dm;
}
