//1.	Write a function which accepts principle, period, rate of interest and returns the simple interest using i=pnr/100 formula. In main() accept these values from the user, call the function and print the interest and total amount.


#include<stdio.h>
void main()
{
	int p,n,r;
	float a;
float calculate(int,int ,int );
printf("enter p,n,r values:");
scanf("%d%d%d",&p,&n,&r);
a= calculate(p,n,r);
printf("\ntotal=%f",a);
}
float calculate(int p,int n,int r)
{
float total,si;

si=(float)((p*n*r)/100);
printf("\nsimple interest =%f",si);
total=p+si;
return total;
}
