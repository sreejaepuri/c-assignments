
//3. In main() accept item_code, current_stock for five items and store them variables. Display each item code one by one and accept received quantity for each of them.  Call a function which accepts item code, stock and received qty and returns the new stock qty. Print the results in main() suitably formatted.
#include<stdio.h>
int code[2],curr_stock[5],rec_qty[2],new_qty,i;
void main()
{
	void accept_itemcode(int rec_qty[],int curr_stock[]);

for(i=0;i<=5;i++)
{
	printf("enter the item code");
	scanf("%d",&code[i]);
	printf("enter current stock");
	scanf("%d",&curr_stock[i]);
	printf("enter the receive item code");
	scanf("%d",&rec_qty[i]);
}
accept_itemcode(rec_qty,curr_stock);
//new_qty=accept_itemcode(rec_qty,curr_stock);
	//printf("%d",new_qty);
}


void accept_itemcode(int rec_qty[],int curr_stock[])
{
	//
	//int rec_qty1=0,
	int new1[12];
	//int code1;


	for(i=0;i<=5;i++)
	{
	//rec_qty[i]=rec_qty[i]+1;
	//printf("%d",rec_qty[i]);
	new1[i]=curr_stock[i]+rec_qty[i];
	printf("\nnew stock is%d",new1[i]);
    }
//return new1;
}