//7. Gross salary = basic + hra  + da. Net salary = gross salary – deductions. Write  a C program  which accepts employee name, id, basic, hra percent, da percent and deduction percent and prints the pay  slip with the details. Develop individual functions to calculate the various components of salary.
#include<stdio.h>
#include<math.h>
void main()
{
int id,net_salary;
char name[12];

int calculate(void);

printf("enter a employee name");
scanf("%s",name);
printf("\nenter a employee id");
scanf("%d",id);
net_salary=calculate();
printf("\nname=%s",name);
printf("\nemployee id=%d",id);
printf("\nnet salry=%d",net_salary);

}
int calculate()
{
int gross_salary,basic,net_salary1;
int hr,da,deduction;
printf("ener a basic salary");
scanf("%d",&basic);
printf("ener a hra");
scanf("%d",&hr);
printf("ener a da");
scanf("%d",&da);
gross_salary=basic+hr+da;
printf("\ngross_salary=%d",gross_salary);
net_salary1=gross_salary-deduction;
return net_salary1;
}
