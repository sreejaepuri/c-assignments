//5. Write a c program which displays the names of  5 colours like 1.Whilte 2. Blue, etc., Accept the option no from the user.  Call a function  by passing this option no. The function will print a prediction based on the number passed to it. Use case statement within the function.
#include<stdio.h>
void main()
{
int c1[5],option;
void prediction(int);

clrscr();
printf("1.blue color");
printf("2.blue color");
printf("3.violet color");
printf("4.pink color");
printf("5.yellow color");
printf("enter ur choice");
scanf("%d",&option);
prediction(option);
}
void prediction(int option)
{
switch(option)
{
case 1:{
	printf("\nyou have selected white color");
break;
}
case 2:{
	printf("\nyou have selected blue ");
break;
}
case 3:{
	printf("\nyou have selected violet color");
break;
}
case 4:{
	printf("\nyou have selected pink color");
break;
}
case 5:{
	printf("\nyou have selected yellow color");
break;
}
default:printf("wrong choice");
break;
}
}