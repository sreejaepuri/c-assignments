//11. Write a function to find if a given string is a palindrome.


#include<stdio.h>
#include<string.h>

void main()
{
int char1;
char s1[12];

void palindrome(char[]);

printf("enter a string");
scanf("%s",s1);
palindrome(s1);
}


void palindrome(char s1[])
{
char ch1[12],ch2[12],string[12];
strcpy(ch1,s1);
strcpy(ch2,ch1);
strrev(ch2);
if(ch1== ch2)
{
printf("it is a palindrome");
}
else
{
printf("it is not a palindrome");
}
}