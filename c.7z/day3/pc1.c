#include<stdio.h>

main()
{
	line();
	printf("helloo");
	
	
	line();
	printf("\t WELCOME ");
}

line()
{
	printf("\n************************\n");
}
