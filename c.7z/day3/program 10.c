

int leap_year=0;
	char dat[3];
	char mon[3];
	char year[5];
	char str[12];
	int i;
	int d,m,y;
	void seperate(void);
	int checking(int);

void main()
{
	
	printf("enter a date.....");
	gets(str);
	seperate();
	//checking();
	d=atoi(dat);
	m=atoi(mon);
	y=atoi(year);
	printf("\n the date is..%d",d);
	printf("\n the month is..%d",m);
	printf("\n the year is..%d",y);
	leap_year=checking(y);
	
	if(leap_year==0)
	{
		if(m==2)
		{
			if(d>=1&&d<=28)
			{
				printf("\ncorrect date ");
			}
			else
			{
				printf("\n wrong date");
			}
		}
		else if(m==1||m==3||m==5||m==7||m==8||m==10||m==12)
		{
			if(d>=1&&d<=31)
			{
				printf("\n correct date");
			}
			else
			{
				printf("\n wrong date");
			}
		}
		else if(m==4||m==6||m==9||m==11)
		{
			if(d>=1&&d<=30)
			{
				printf("\n correct date");
			}
			else
			{
				printf("\n wrong date");
			}

		}
		else
		{
			printf("\n invalid input");
		}
	}
	
	
}
	
	
void seperate()
{
	int j=0,k=0,l=0;	
	for(i=0;i<10;i++)
	{
		if(i==0||i==1)
		{
			dat[j]=str[i];
			j++;
			
		}
		if(i==3||i==4)
		{
			mon[k]=str[i];
			k++;
			
		}
		if(i==6||i==9)
		{
			year[l]=str[i];
			l++;	
		}
	}			
}
	
	
	
	
int checking(int)
{
	if(y%4==0&&y%400==0)
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}
		
		
	