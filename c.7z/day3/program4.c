//4. In main() accept a password from the user and store it in a global variable. Write a function which simulates a login and accepts the password from the user. Compare it with previously stored password and display suitable message.

#include<stdio.h>
#include<string.h>
void main()
{

char ch1[12],ch2[12];
void login(char [],char[]);
printf("enter the user login id:");
scanf("%s",ch1);
printf("enter the user  pwrd:");
scanf("%s",ch2);
login(ch1,ch2);
}



void login(char ch1[],char ch2[])
{
//static int login1;
int a1,a2;
static int login2;
char s1[12],s2[12],ch;
printf("do u want to continue (Y/N)");
flushall();
scanf("%c",&ch);
while(ch=='Y')
{
	printf("enter the  login id:");
	scanf("%s",s1);
	printf("enter the  pwrd:");
	scanf("%s",s2);
	a1=strcmp(s1,ch1);
	a2=strcmp(s2,ch2);
if(login2<3)
{
	if(a1==0 && a2==0)
	{
		//login1++;
		printf("user name and pwrd are matched");
		//printf("\nyou have logged in ..:%d",login1);
		break;
	}
	else
	{
		//login2++;
		printf(" both are not matched");
	}
}

}

}