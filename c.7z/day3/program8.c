//8. Foods Inc, an eatery  needs to develop a billing program which will  generate  a bills  for its customers. Service Charge 2% and service tax 11% needs to be included. Develop the program in  a modular way with the help of functions.
#include<stdio.h>
void main()
{
	int bill;
	float total;
float  billing(int);

printf("enter the customer bill");
scanf("%d",&bill);
printf("%d",bill);
total=billing(bill);
printf("\ntotal=%f",total);


}
float billing(int bill)
{
	float total_bill;
int incl_charge,tax,incl_tax,charge;


incl_charge=bill=(bill*(float)2/(100.0))+bill;
printf("\ncharge=%d",incl_charge);



incl_tax=((float)(11/100.0)*bill)+bill;
printf("\nbill+tax=%d",incl_tax);

total_bill=bill+(bill*(float)(2/100.0))+(bill*(float) (11/100.0));
return total_bill;
}