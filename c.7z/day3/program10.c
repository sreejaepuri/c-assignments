#include<stdio.h>
int date[3],
void main()
{
	void seperating(void);
	void checking_leapyear(void);
	//void checking_nonleapyear();
	seperating();
	checking_leapyear();

}
void separating()
{
char str[10];
int i=0,d=0,m=0,y=0;
for(i>=0&&i<=1)
{
printf("\nenter the date...:");
scanf("%d",&d);
}
for(i<=4&&i>=3)
{
printf("\nenter the month...:");
scanf("%d",&m);
}
for(i>=6&&i<=9)
{
printf("\nenter the year...:");
scanf("%d",&y);
}
printf("enter the date..:%d-%d-%d",d,m,y);
printf("%s",str);
}
void checking_leapyear(char str[])
{
	if(y>=1000&&y<=9999)
	{
		
	}
	
	
	
	
}


